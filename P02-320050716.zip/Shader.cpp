#include "Shader.h"



Shader::Shader()
{
		shaderID = 0;
		uniformModel = 0;
		uniformProjection = 0;
		uniformColor = 0;
	
	//Ir agregando nuevas variables Uniform

}

void Shader::CreatefromString(const char* vertexCode, const char* fragmentCode)
{
	CompileShader(vertexCode, fragmentCode);
}
void Shader::CreateFromFiles(const char* vertexLocation, const char* fragmentLocation)
{
	std::string vertexString = ReadFile(vertexLocation);
	std::string fragmentString = ReadFile(fragmentLocation);
	const char* vertexCode = vertexString.c_str();
	const char* fragmentCode = fragmentString.c_str();

	CompileShader(vertexCode, fragmentCode);

}

std::string Shader::ReadFile(const char* fileLocation)
{
	std::string content;
	std::ifstream fileStream(fileLocation, std::ios::in);
	if (!fileStream.is_open())
	{
		printf("Fall� en leer el archivo: %s", fileLocation);
		return "";
	}
	std::string line = "";
	while (!fileStream.eof())
	{
		std::getline(fileStream, line);
		content.append(line + "\n");
	}
	fileStream.close();
	return content;
}



void Shader::CompileShader(const char* vertexCode, const char* fragmentCode)
{
	shaderID = glCreateProgram(); //se crea un programa
	if (!shaderID)
	{
		printf("Error creando el shader");
		return;
	}
	AddShader(shaderID, vertexCode, GL_VERTEX_SHADER);//Agregar vertex shader
	AddShader(shaderID, fragmentCode, GL_FRAGMENT_SHADER);//Agregar fragment shader
												   //Para terminar de linkear el programa y ver que no tengamos errores
	GLint result = 0;
	GLchar eLog[1024] = { 0 };
	glLinkProgram(shaderID);//se linkean los shaders a la tarjeta gr�fica
						  //verificaciones y prevenci�n de errores
	glGetProgramiv(shaderID, GL_LINK_STATUS, &result);
	if (!result)
	{
		glGetProgramInfoLog(shaderID, sizeof(eLog), NULL, eLog);
		printf("EL error al linkear es: %s \n", eLog);
		return;
	}
	glValidateProgram(shaderID);
	glGetProgramiv(shaderID, GL_VALIDATE_STATUS, &result);
	if (!result)
	{
		glGetProgramInfoLog(shaderID, sizeof(eLog), NULL, eLog);
		printf("EL error al validar es: %s \n", eLog);
		return;
	}

	uniformProjection = glGetUniformLocation(shaderID, "projection");
	uniformModel = glGetUniformLocation(shaderID, "model");
	uniformColor = glGetUniformLocation(shaderID, "uniformColor"); 
	//Ir agregando nuevas variables Uniform
}

GLuint Shader::getProjectLocation()
{
	return uniformProjection;
}
GLuint Shader::getModelLocation()
{	
	return uniformModel;
}
//agregar get para nuevas variables uniform

void Shader::useShader()
{
	glUseProgram(shaderID);

}

void Shader::ClearShader()
{
	if (!shaderID)
	{ 
		glDeleteProgram(shaderID);//borra programa de la tarjeta gr�fica
		shaderID = 0;
	}
	uniformModel = 0;
	uniformProjection = 0;
	//Ir agregando nuevas variables Uniform para limpiar 
}
void Shader:: AddShader(GLuint theProgram, const char* shaderCode, GLenum shaderType) //Funci�n para agregar los shaders a la tarjeta gr�fica
																			 //the Program recibe los datos de theShader

{
	GLuint theShader = glCreateShader(shaderType);//theShader es un shader que se crea de acuerdo al tipo de shader: vertex o fragment
	const GLchar* theCode[1];
	theCode[0] = shaderCode;//shaderCode es el texto que se le pasa a theCode
	GLint codeLength[1];
	codeLength[0] = strlen(shaderCode);//longitud del texto
	glShaderSource(theShader, 1, theCode, codeLength);//Se le asigna al shader el c�digo
	glCompileShader(theShader);//Se comila el shader
	GLint result = 0;
	GLchar eLog[1024] = { 0 };
	//verificaciones y prevenci�n de errores
	glGetShaderiv(theShader, GL_COMPILE_STATUS, &result);
	if (!result)
	{
		glGetProgramInfoLog(shaderID, sizeof(eLog), NULL, eLog);
		printf("EL error al compilar el shader %d es: %s \n", shaderType, eLog);
		return;
	}
	glAttachShader(theProgram, theShader);//Si no hubo problemas se asigna el shader a theProgram el cual asigna el c�digo a la tarjeta gr�fica
}

Shader::~Shader()
{
	ClearShader();
}

GLuint Shader::getColorLocation() {
	return uniformColor;
}