#version 330
out vec4 color;
uniform vec3 uniformColor; // Aquí enviaremos el color desde C++
void main() {
    color = vec4(uniformColor, 1.0);
}